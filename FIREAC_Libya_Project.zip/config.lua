
-- FIREAC-Libya Configuration
-- This is where you can customize the behavior of the anti-cheat system.

Config = {}

-- Server Branding
Config.Branding = "Libyan Ministry"

-- Cheat Detection Settings
Config.EnableAdvancedDetection = true
Config.AlertAdmins = true
Config.LogAllEvents = true

-- Resource Optimization
Config.OptimizeResources = true
